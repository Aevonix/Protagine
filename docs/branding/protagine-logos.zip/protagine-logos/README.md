# Aevonix Research and Protagine / approved press kit

September 2026. Aevonix Research uses the Spectrum identity; Protagine uses the Engine symbol with a Stencil wordmark and the descriptor Proto AGI Engine. The new Protagine identity continues the cream, amber, coral and teal palette; Aevonix retains its existing Spectrum geometry.

## Start here

- `brand-overview.pdf` and `.png`: Both identities and the core palette on one sheet.
- `brand-guide.pdf`: Six-page illustrated guide covering artwork, clear space, sizes, color, typography, design rules, press copy and contact.
- `brand-guide.md`: The same guidance as readable and searchable text.
- `press-copy.md`, `.txt`, `.json`: Company/project descriptions, founder biography, facts and names.
- `aevonix/`, `protagine/`: Primary, compact and mark layouts; dark, light, black and white versions; SVG, vector PDF and transparent PNG.
- `icons/`: Aevonix favicon, app icon and Apple touch icon.
- `palette.css`, `.json`, `.gpl`: CSS values, structured sRGB colors and a GIMP/Inkscape palette. The `.gpl` extension identifies the color file format, not a license.
- `manifest.json`: File sizes and SHA-256 checksums of the exports.

In the full ZIP, the files above are under `exports/`. Editable construction data and the build script are under `source/`, alongside the original font files, download records and license notices. Individual brand ZIPs contain the corresponding logo files, this README, the text guide and palette files; they do not include the full source or all guide exports.

The filename `dark` means light inks intended for a dark background. `light` supplies graphite lettering and darker accent inks for a light background. All individual SVG, PDF and PNG logos are transparent; the avatars, icons, overview and guide have intentional backgrounds. Primary and compact PNGs are 1600 pixels wide; symbols are 1024 × 1024. Small icon PNGs are 16, 24, 32 or 48 pixels. Avatar tiles are 512 × 512.

Aevonix primary includes Research. The compact Aevonix signature needs a separate visible Research label where the full company name is needed. Protagine primary includes Proto AGI Engine; the compact version omits the descriptor. In running text write Aevonix Research and Protagine.

## Build from the repository

```sh
python3 -m venv /tmp/aevonix-vector-tools
/tmp/aevonix-vector-tools/bin/pip install -r design/identity/brand/requirements.txt
/tmp/aevonix-vector-tools/bin/python design/identity/brand/build.py
```

## Build from the extracted press kit

From the `aevonix-press-kit` directory:

```sh
python3 -m venv .venv
.venv/bin/pip install -r source/requirements.txt
.venv/bin/python source/build.py --output ./rebuilt
```

Cairo must be available on the host. On Debian/Ubuntu it is provided by `libcairo2`; on macOS it is available through Homebrew’s `cairo` package. The generator uses only the bundled files. It does not fetch fonts or require an earlier design round. The SVGs contain filled paths with no raster images, live fonts, gradients, filters or clipping masks. HarfBuzz shapes Archivo and Space Mono; FontTools outlines glyphs; Skia PathOps resolves authored geometry; CairoSVG makes vector PDFs and transparent PNGs; pypdf combines guide pages; Pillow writes the multi-resolution favicon.

`marks.json` is the selected AE and P construction geometry. Archivo wordmarks use width 110, weight 780 and the retained custom stencil cuts. The type setting, spacing, mark geometry and ink mapping match the selected artwork. The guide uses Geist for headings and body copy, and Space Mono for captions; the website uses Geist and Geist Mono. Metadata identifies the approved identities rather than the old comparison round.

## Use and contact

Use the supplied artwork when referring to Aevonix Research or Protagine. Keep the names, proportions and colors intact. For press requests, co-branding or other usage questions, contact Maggie@aevonix.com.

The fonts retain their original license notices. The open source status of Protagine and the research does not itself license the brand assets. This kit does not introduce a trademark or software license for the logos.
