# Aevonix Research and Protagine / brand guide

Approved identities. September 2026.

- Aevonix Research: Spectrum.
- Protagine: Engine, with the Stencil wordmark.
- Contact: Maggie@aevonix.com
- Website: https://aevonix.com/branding

## Choose the right logo

Use the supplied artwork. All signatures and standalone symbols have transparent backgrounds.

- `primary`: Aevonix includes the Research descriptor. Protagine includes Proto AGI Engine.
- `compact`: A more compact horizontal signature. Aevonix omits the Research descriptor; add a visible Research label when the full company name is needed.
- `mark`: The standalone AE or P symbol. Pair it with an accessible name in an interface.
- `dark`: Light inks intended for graphite and similar dark surfaces.
- `light`: Graphite lettering and approved darker color inks for cream or white surfaces.
- `black` and `white`: Single-ink alternatives for constrained reproduction.

Do not choose a variant by its filename alone: `dark` describes the intended background, not the ink. Do not place white artwork on a light surface or black artwork on graphite. On photographs, put the logo on a clear, quiet area with reliable contrast, or use a solid brand-color panel.

## Clear space

Let H be the visible symbol height. Keep at least 0.25H clear around the entire logo, including lettering and any descriptor. Measure from visible artwork, not the SVG canvas. The exported canvas padding is not a substitute for this space. See the illustrated PDF guide, page 2.

When two logos appear together, leave at least 0.5H between visible artwork: twice the standard clear space, using the larger symbol height. Keep independent logos distinct. Do not combine them into a new mark or imply an endorsement through their placement or wording.

## Recommended minimum screen sizes

| Artwork | Width | Notes |
| --- | ---: | --- |
| Aevonix primary | 240 px | Includes Research. |
| Aevonix compact | 160 px | Add a separate Research label where the full company name is needed. |
| Protagine primary | 320 px | Includes Proto AGI Engine. |
| Protagine compact | 200 px | Wordmark without the descriptor. |
| Standalone symbols | 24 px | Recommended when the cuts and return geometry need to be visible. |
| Favicon or tiny application icon | 16 px | Fine interruptions and returns soften at this size. |

These are CSS-pixel recommendations. Use the supplied 16, 24, 32 and 48 pixel icon PNGs only at their intended size; scale SVGs for larger uses. Inspect at 100% zoom. For print, proof on the final material at the final size; preserve the stencil openings.

## Color guide

All values are sRGB. The alternate light-surface inks are already applied to the `light` files. Do not recolor the dark artwork to approximate them.

| Color | HEX | RGB | Role |
| --- | --- | --- | --- |
| Graphite | `#151615` | 21, 22, 21 | Primary brand surface |
| Cream | `#F3E5CD` | 243, 229, 205 | Primary ink on graphite; light surface |
| Amber | `#EEB07E` | 238, 176, 126 | Aevonix symbol; Protagine outer return |
| Teal | `#A9D5CE` | 169, 213, 206 | Aevonix lower arm; Protagine inner return |
| Coral | `#D99288` | 217, 146, 136 | Aevonix middle arm; Protagine inset |
| Muted cream | `#C0B4A0` | 192, 180, 160 | Research descriptor and secondary ink |
| Site canvas | `#131416` | 19, 20, 22 | Website canvas and Safari header |
| Light-surface amber | `#854719` | 133, 71, 25 | Approved light-surface logo ink |
| Light-surface teal | `#285F58` | 40, 95, 88 | Approved light-surface logo ink |
| Light-surface coral | `#99483D` | 153, 72, 61 | Approved light-surface logo ink |
| Light-surface muted ink | `#555449` | 85, 84, 73 | Research descriptor on light surfaces |

Use cream body text on graphite, or graphite on cream. Accent colors identify parts of the artwork and support restrained interface details. Keep labels readable; color should not be the only way information is conveyed. The site canvas is intentionally a slightly cooler graphite than the main brand surface.

`palette.css` supplies CSS custom properties. `palette.json` records names, HEX, RGB and roles. `palette.gpl` is a GIMP/Inkscape palette, not a software license. No Pantone or CMYK equivalents are supplied. Ask the printer to proof color for the selected process and material rather than assuming an automatic conversion is a brand specification.

## Typography

The logo lettering is based on Archivo with custom stencil openings. Use the supplied outlined artwork; do not retype or reconstruct it.

The website uses Geist for headings and body copy, and Geist Mono for labels and numerical details.

Space Mono is used for captions in the downloadable vector guide. Font source files carry their own licenses.

The guide uses Geist for body copy and headings. Website font information: https://vercel.com/font. Archivo source: https://github.com/Omnibus-Type/Archivo. Original font files, notices and download records are in `source/fonts`. The supplied logo SVGs contain outlined paths and require no font installation.

## Presentation and motion

- Use graphite or cream fields, measured spacing and simple panel divisions.
- Keep headlines and body copy prominent. Instrument details and CRT texture are supporting elements.
- Keep the logo static, proportional and intact. Do not stretch, crop, rotate, outline, redraw or retype it.
- Do not add new colors, gradients, shadows or glow to the artwork.
- Do not place scanlines, grids, moving lights or other effects through the logo. They may appear around it if the identity stays clear.
- Animate surrounding interface details or demonstrations. Respect the operating system’s reduced-motion preference and keep content understandable without movement.
- Use the approved light variant or one-ink artwork when the background calls for it.

## File formats and downloads

For each brand, the kit includes primary, compact and mark layouts in dark, light, black and white:

`{aevonix|protagine}-{primary|compact|mark}-{dark|light|black|white}.{svg|pdf|png}`

- SVG: Editable native filled vector paths; outlined lettering; no live fonts, raster images, filters, clipping masks or gradients.
- PDF: Vector copies of every logo, a branding overview and the six-page guide.
- PNG: Transparent primary/compact signatures at 1600 px wide, symbols at 1024 px square, small icons at 16/24/32/48 px, and graphite avatar tiles at 512 px square.
- Platform icons: Aevonix favicon with 16–256 px resolutions, vector app icon, and a 180 px Apple touch icon.
- Press copy: Markdown, plain text and structured JSON with descriptions, founder biography, facts and names.
- Source: Selected geometry, portable build script, pinned dependencies, fonts and original font notices.

`aevonix-press-kit.zip` contains both approved identities, all exports, the guide, press copy and source. `aevonix-logos.zip` and `protagine-logos.zip` contain each brand’s exports plus a concise guide and palette. Earlier design studies are not part of these archives.

## Names and press copy

**Aevonix Research:** Use the full company name on first reference. Aevonix is acceptable on subsequent references.

**Protagine:** Write Protagine with a capital P in running text. The name stands for Proto AGI Engine. Use the supplied uppercase wordmark.

**PAGI:** Expand as Proto-AGI on first reference. Describe it as ongoing research, not an achieved capability.

**Hermes:** Describe Protagine as built for Hermes.

Use `press-copy.md`, `.txt` or `.json` for the supplied descriptions, founder biography and facts. Preserve the distinction between ongoing PAGI research and an achieved capability; Protagine is built for Hermes. SPVs launch in 2027.

## Artwork use and contact

Use the supplied artwork when referring to Aevonix Research or Protagine. Keep the names, proportions and colors intact. For press requests, co-branding or other usage questions, contact Maggie@aevonix.com.

The fonts retain their own licenses. A software repository’s open source license does not itself grant a license to the brand assets. This kit does not introduce a new trademark or software license for the logos.
